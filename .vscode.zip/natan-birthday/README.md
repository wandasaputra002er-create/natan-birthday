# Natan — A Little Universe
A personal birthday keepsake. Plain HTML, CSS and vanilla JavaScript. No backend, no build step, no database.

## Structure
```
natan-birthday/
├── index.html
├── css/style.css
├── js/script.js
├── assets/
│   ├── natan.jpg        <- hero photo (required path)
│   └── memories/        <- extra photos
└── README.md
```

## Hero photo
Save Natan's photograph as `assets/natan.jpg`. It is displayed untouched. If it is missing, a "Photo not found" placeholder shows instead of a broken image.

## Add more photographs (3-8 total)
1. Copy the images into `assets/memories/`.
2. In `js/script.js`, add entries to the `MEMORIES` array:
   `{ src: 'assets/memories/photo1.jpg', caption: 'Your caption', date: 'Your date' },`
3. Captions and dates can also be edited on the page (tap the text); edits are kept in that browser only.
Empty slots appear as placeholders until photos are added.

## Run locally
- Double-click `index.html`, or
- From this folder: `python3 -m http.server 8000`, then open http://localhost:8000

To share it, upload the folder to any static host (GitHub Pages, Netlify, Cloudflare Pages).

## What is inside
Page transitions with working Back button, canvas night sky with parallax and shooting stars, day/night toggle, live age and birthday countdown, tilt Polaroid, paw menu with keyboard arrows, animated envelope (skip / read again), scrapbook gallery with swipeable lightbox, tappable cats, and a wish page where every saved wish becomes a star in a private constellation (up to 12, stored in localStorage only). Animations respect "reduce motion".

## Music
Tap the ♪ button (top-left) to start. Browsers never allow music to start by itself, so a tap is always needed.
- By default it plays an original music-box lullaby generated live in the browser (no files, no copyright issues).
- To use a real song instead, save it as `assets/music.mp3`. It is picked up automatically and loops. Only use music you have the right to use.
- A volume slider appears while music plays; the level is remembered in this browser.

## More in this version
- **Gate:** a first screen ("Enter with music" / "Enter quietly"); the tap is also what lets browsers start sound.
- **Birthday Cake:** number candles for the age he is turning. Blow into the microphone (only after pressing the button; nothing is recorded or sent) or use the tap button. Fireworks follow. On 3 January fireworks also start by themselves.
- **Universe Map:** orbiting planets that link to every page.
- **Sound:** all audio is generated live by `js/audio.js` (music, ambience, sound effects, mixer with sound lab). Open the `mix` button (top-left) to set volumes, mute, choose ambience, or preview every effect.
- **Star card:** on the wish page, saves a PNG of the wish constellation to the device. It contains the wishes, so share it only if wanted.

## Memories: six frames
`js/script.js` has a `MEMORIES` array with six entries. Each frame turns over to show a message on the back.
- Frame 1 is Natan's photo. For the other five, set `src` to a file in `assets/memories/` (for example `'assets/memories/photo2.jpg'`); until then they show "Your photo goes here" but still turn over.
- The messages on the back are gentle placeholders. Rewrite them in your own words, either in the `note` fields or by tapping the text on the card (saved in that browser only).
- Photos can be enlarged in a lightbox with previous/next, swipe and arrow keys.

## Time of day
The theme button (top-right) cycles **Auto → Day → Night**. In Auto the whole site follows the visitor's local time: dawn, morning, midday, afternoon, golden-hour sunset, dusk, night. Background colours change, clouds warm up at sunset, and a sun or crescent moon travels across the sky.

## Hidden surprise
Tapping the cats on the Surprise page 20 times (the count is remembered in the browser, so it can be spread over visits) opens a message with fireworks. Edit the words in the `SECRET` object near the top of `js/script.js`; `{age}` becomes the age he is turning.

## New pages
- **Natan in Numbers:** live counters since 3 January 2007 (days, weeks, hours, trips around the Sun, kilometres travelled with the Earth, moon cycles, heartbeats at an assumed 70 bpm), the moon on his birth date and tonight, and a few birth facts. Everything is calculated, nothing is invented.
- **Open When…:** six small envelopes. Replace the words in the `NOTES` array in `js/script.js`; the ones already opened are remembered in the browser.
- **Letter:** a "Handwriting" button switches the letter to a handwritten font.
- **Hero photo:** it "develops" like a Polaroid when the page loads. This is a CSS effect only; the photo file is never changed.
- **Offline / install:** when served over http(s) (not by double-clicking the file), `sw.js` and `manifest.webmanifest` let the site work offline and be added to a phone's home screen.
